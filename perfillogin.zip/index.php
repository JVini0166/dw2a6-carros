<?php

session_save_path(__DIR__ . '/sessions');
session_start();
// Conexão com o banco de dados
$servername = "br424.hostgator.com.br";
$username = "alsoac40_dw2a6";
$password = "MaçãComPaçoca2024";
$dbname = "alsoac40_vrum";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Funções de Registro e Login
$erro = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['register'])) {
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $telefone = $_POST['telefone'];
        $cpf = $_POST['cpf'];
        $genero = $_POST['genero'];
        $data_nascimento = $_POST['data_nascimento'];
        $cep = $_POST['cep'];
        $endereco = $_POST['endereco'];
        $estado = $_POST['estado'];
        $cidade = $_POST['cidade'];
        $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);

        $sql = "INSERT INTO Usuarios (nome, email, telefone, cpf, genero, data_nascimento, cep, endereco, estado, cidade, senha)
                VALUES ('$nome', '$email', '$telefone', '$cpf', '$genero', '$data_nascimento', '$cep', '$endereco', '$estado', '$cidade', '$senha')";

        if ($conn->query($sql) === TRUE) {
            $mensagem = "Cadastro realizado com sucesso!";
        } else {
            $erro = "Erro: " . $sql . "<br>" . $conn->error;
        }
    } elseif (isset($_POST['login'])) {
        $email = $_POST['loginEmail'];
        $senha = $_POST['loginSenha'];

        $sql = "SELECT * FROM Usuarios WHERE email='$email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($senha, $row['senha'])) {
                session_start();
                $_SESSION['id'] = $row['id'];
                $_SESSION['nome'] = $row['nome'];
                header("Location: perfil.php");
                exit();
            } else {
                $erro = "Senha incorreta.";
            }
        } else {
            $erro = "Usuário não encontrado.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        body {
            background-color: #D9D9D9;
        }
        .header, .footer {
            background-color: #100E75;
            color: white;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
        }
        .nav-link {
            color: white;
        }
        .nav-link:hover {
            color: #E37611;
        }
        .form-container {
            background-color: #100E75;
            padding: 30px;
            border-radius: 10px;
            margin: 20px;
            color: white;
        }
        .form-container h3 {
            margin-bottom: 20px;
        }
        .btn-custom {
            background-color: #E37611;
            color: white;
            border: none;
            margin-top: 10px;
        }
        .btn-custom:hover {
            background-color: #ff9d47;
        }
        .footer {
            background-color: #ff7f00;
            color: white;
            text-align: center;
            padding: 10px 0;
        }
    </style>
</head>
<body>
    <header class="header py-3">
        <div class="container d-flex justify-content-between align-items-center">
            <div class="logo">LOGO</div>
            <nav>
                <a class="nav-link d-inline-block mx-2" href="comprar.php">Comprar</a>
                <a class="nav-link d-inline-block mx-2" href="vender.php">Vender</a>
                <a class="nav-link d-inline-block mx-2" href="perfil.php">Serviços</a>
                <a class="nav-link d-inline-block mx-2" href="#">Ajuda</a>
            </nav>
            <a class="nav-link d-inline-block" href="#">Entrar</a>
        </div>
    </header>

    <div class="container my-5">
        <div class="row">
            <div class="col-md-6">
                <div class="form-container">
                    <h3>Cadastrar-se</h3>
                    <?php if (!empty($erro)) { echo "<div class='alert alert-danger'>$erro</div>"; } ?>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="nome">Nome</label>
                            <input type="text" class="form-control" id="nome" name="nome" placeholder="Seu nome" required>
                        </div>
                        <div class="form-group">
                            <label for="email">E-mail</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Seu e-mail" required>
                        </div>
                        <div class="form-group">
                            <label for="telefone">Telefone</label>
                            <input type="tel" class="form-control" id="telefone" name="telefone" placeholder="Seu telefone">
                        </div>
                        <div class="form-group">
                            <label for="cpf">CPF</label>
                            <input type="text" class="form-control" id="cpf" name="cpf" placeholder="Seu CPF" required>
                        </div>
                        <div class="form-group">
                            <label for="genero">Gênero</label>
                            <select class="form-control" id="genero" name="genero" required>
                                <option value="">Selecione</option>
                                <option value="Masculino">Masculino</option>
                                <option value="Feminino">Feminino</option>
                                <option value="Outro">Outro</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="data_nascimento">Data de Nascimento</label>
                            <input type="date" class="form-control" id="data_nascimento" name="data_nascimento" required>
                        </div>
                        <div class="form-group">
                            <label for="cep">CEP</label>
                            <input type="text" class="form-control" id="cep" name="cep" placeholder="Seu CEP">
                        </div>
                        <div class="form-group">
                            <label for="endereco">Endereço</label>
                            <input type="text" class="form-control" id="endereco" name="endereco" placeholder="Seu endereço">
                        </div>
                        <div class="form-group">
                            <label for="estado">Estado</label>
                            <input type="text" class="form-control" id="estado" name="estado" placeholder="Seu estado">
                        </div>
                        <div class="form-group">
                            <label for="cidade">Cidade</label>
                            <input type="text" class="form-control" id="cidade" name="cidade" placeholder="Sua cidade">
                        </div>
                        <div class="form-group">
                            <label for="senha">Senha</label>
                            <input type="password" class="form-control" id="senha" name="senha" placeholder="Sua senha" required>
                        </div>
                        <button type="submit" name="register" class="btn btn-custom btn-block">Cadastrar</button>
                    </form>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-container">
                    <h3>Logar</h3>
                    <?php if (!empty($erro)) { echo "<div class='alert alert-danger'>$erro</div>"; } ?>
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="loginEmail">E-mail</label>
                            <input type="email" class="form-control" id="loginEmail" name="loginEmail" placeholder="Seu e-mail" required>
                        </div>
                        <div class="form-group">
                            <label for="loginSenha">Senha</label>
                            <input type="password" class="form-control" id="loginSenha" name="loginSenha" placeholder="Sua senha" required>
                        </div>
                        <button type="submit" name="login" class="btn btn-custom btn-block">Logar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <footer class="footer mt-5">
        <p>@criador</p>
    </footer>
</body>
</html>
