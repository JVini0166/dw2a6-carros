<?php
$servername = "br424.hostgator.com.br";
$username = "alsoac40_dw2a6";
$password = "MaçãComPaçoca2024";
$dbname = "alsoac40_vrum";

// Criar a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}
?>
