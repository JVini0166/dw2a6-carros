<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comprar</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="header">
        <div class="logo">LOGO</div>
        <nav>
            <a href="comprar.php">Comprar</a>
            <a href="vender.html">Vender</a>
            <a href="#">Serviços</a>
            <a href="#">Ajuda</a>
        </nav>
        <a href="login.html" class="login-link">Entrar</a>
    </header>

    <div class="container">
        <h1>Lista de Veículos</h1>
        <div class="content">
            <?php
            include 'db.php';

            $sql = "SELECT * FROM Veiculos";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table class='table table-striped'>";
                echo "<thead>";
                echo "<tr>";
                echo "<th>Marca</th>";
                echo "<th>Modelo</th>";
                echo "<th>Versão</th>";
                echo "<th>Ano</th>";
                echo "<th>Quilometragem</th>";
                echo "<th>Cor</th>";
                echo "<th>Preço</th>";
                echo "<th>Ação</th>";
                echo "</tr>";
                echo "</thead>";
                echo "<tbody>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['marca']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['modelo']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['versao']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['ano_modelo']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['quilometragem']) . " km</td>";
                    echo "<td>" . htmlspecialchars($row['cor']) . "</td>";
                    echo "<td>R$ " . htmlspecialchars($row['valor']) . "</td>";
                    echo "<td><a href='detalhes.php?id=" . $row['id'] . "' class='btn btn-primary'>Ver Detalhes</a></td>";
                    echo "</tr>";
                }

                echo "</tbody>";
                echo "</table>";
            } else {
                echo "<p>Nenhum veículo encontrado.</p>";
            }

            $conn->close();
            ?>
        </div>
    </div>

    <footer class="footer">
        <p>@criador</p>
    </footer>
</body>
</html>
